Linux:
On linux only python installation is needed
and usually python is included.


Windows:
To use the python script on windows
Python for Windows extensions have to be installed

http://sourceforge.net/projects/pywin32

